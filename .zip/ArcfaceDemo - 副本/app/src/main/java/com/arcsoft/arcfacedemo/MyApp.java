package com.arcsoft.arcfacedemo;

import android.app.Application;

/**
 * TODO
 *
 * @author Kelly
 * @version 1.0.0
 * @filename MyApp
 * @time 2020/11/17 15:01
 * @copyright(C) 2020 泰中科技
 */
public class MyApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

    }





}
