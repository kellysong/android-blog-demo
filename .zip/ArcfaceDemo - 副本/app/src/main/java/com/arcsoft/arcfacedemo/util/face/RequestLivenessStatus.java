package com.arcsoft.arcfacedemo.util.face;

public class RequestLivenessStatus {
    public static final int ANALYZING = 10;
}
